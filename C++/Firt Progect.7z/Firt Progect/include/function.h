#pragma once
void initial_data();
void initial_statistic();
void initial_log();
int menu_out();
void gover_menu_out();
